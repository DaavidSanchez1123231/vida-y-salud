package pe.com.VidaySalud.dto;

public class AuthLoginResponseDTO {

    private String token;
    private String username;   // Para mostrar "Hola, Juan"
    private String rol;        // ¡CRUCIAL! Para saber a qué carpeta ir
    private Integer idUsuario; // Para hacer peticiones (ej: ver MIS citas)

    // Constructor vacío (necesario a veces para librerías JSON)
    public AuthLoginResponseDTO() {}

    // Constructor simple (por si acaso lo usabas antes)
    public AuthLoginResponseDTO(String token) {
        this.token = token;
    }

    // --- ESTE ES EL CONSTRUCTOR NUEVO QUE USA EL AUTHSERVICE ---
    public AuthLoginResponseDTO(String token, String username, String rol, Integer idUsuario) {
        this.token = token;
        this.username = username;
        this.rol = rol;
        this.idUsuario = idUsuario;
    }

    // --- Getters y Setters ---
    public String getToken() {
        return token;
    }
    public void setToken(String token) {
        this.token = token;
    }

    public String getUsername() {
        return username;
    }
    public void setUsername(String username) {
        this.username = username;
    }

    public String getRol() {
        return rol;
    }
    public void setRol(String rol) {
        this.rol = rol;
    }

    public Integer getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(Integer idUsuario) {
        this.idUsuario = idUsuario;
    }
}