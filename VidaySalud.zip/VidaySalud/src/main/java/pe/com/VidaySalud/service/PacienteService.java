package pe.com.VidaySalud.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import pe.com.VidaySalud.dto.PacienteRequestDTO;
import pe.com.VidaySalud.dto.PacienteResponseDTO;
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Paciente;
import pe.com.VidaySalud.repository.PacienteRepository;

@Service
public class PacienteService {

    @Autowired
    private PacienteRepository pacienteRepository;

    // --- 1. OBTENER TODOS ---
    public List<PacienteResponseDTO> obtenerTodosLosPacientes() {
        return pacienteRepository.findAll()
                .stream()
                .map(this::convertirA_ResponseDTO)
                .collect(Collectors.toList());
    }

    // --- 2. CREAR PACIENTE ---
    // NOTA: Este método es usado para CRUD interno. La creación de usuario/login se maneja en AuthService.
    public PacienteResponseDTO crearPaciente(PacienteRequestDTO requestDTO) {
        Paciente paciente = convertirA_Entidad(requestDTO);
        Paciente pacienteGuardado = pacienteRepository.save(paciente);
        return convertirA_ResponseDTO(pacienteGuardado);
    }

    // --- 3. OBTENER POR ID ---
    public PacienteResponseDTO obtenerPacientePorId(Integer id) {
        Paciente paciente = pacienteRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));
        return convertirA_ResponseDTO(paciente);
    }

    // --- 4. ELIMINAR ---
    public void eliminarPaciente(Integer id) {
        if (!pacienteRepository.existsById(id)) {
            throw new ResourceNotFoundException("Paciente no encontrado con ID: " + id);
        }
        pacienteRepository.deleteById(id);
    }

    // --- 5. ACTUALIZAR COMPLETO (PUT) ---
    public PacienteResponseDTO actualizarPaciente(Integer id, PacienteRequestDTO requestDTO) {
        
        Paciente pacienteExistente = pacienteRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));

        // Actualizamos TODOS los campos (Incluyendo Teléfono)
        pacienteExistente.setDniPaciente(requestDTO.getDniPaciente());
        pacienteExistente.setNomPaciente(requestDTO.getNomPaciente());
        pacienteExistente.setApPaciente(requestDTO.getApPaciente());
        pacienteExistente.setAmPaciente(requestDTO.getAmPaciente());
        pacienteExistente.setEmailPaciente(requestDTO.getEmailPaciente());
        pacienteExistente.setFnPaciente(requestDTO.getFnPaciente()); 
        pacienteExistente.setTelfPaciente(requestDTO.getTelfPaciente()); // CAMPO AGREGADO
      
        Paciente pacienteActualizado = pacienteRepository.save(pacienteExistente);
        return convertirA_ResponseDTO(pacienteActualizado);
    }

    // --- 6. ACTUALIZAR PARCIAL (PATCH) ---
    public PacienteResponseDTO actualizarPacienteParcial(Integer id, PacienteRequestDTO requestDTO) {
        
        Paciente pacienteExistente = pacienteRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Paciente no encontrado con ID: " + id));

        // Actualizamos solo si el campo viene en el DTO
        if (requestDTO.getDniPaciente() != null) {
            pacienteExistente.setDniPaciente(requestDTO.getDniPaciente());
        }
        if (requestDTO.getNomPaciente() != null) {
            pacienteExistente.setNomPaciente(requestDTO.getNomPaciente());
        }
        if (requestDTO.getApPaciente() != null) {
            pacienteExistente.setApPaciente(requestDTO.getApPaciente());
        }
        if (requestDTO.getAmPaciente() != null) {
            pacienteExistente.setAmPaciente(requestDTO.getAmPaciente());
        }
        if (requestDTO.getEmailPaciente() != null) {
            pacienteExistente.setEmailPaciente(requestDTO.getEmailPaciente());
        }
        if (requestDTO.getFnPaciente() != null) {
            pacienteExistente.setFnPaciente(requestDTO.getFnPaciente());
        }
        if (requestDTO.getTelfPaciente() != null) { // CAMPO AGREGADO
            pacienteExistente.setTelfPaciente(requestDTO.getTelfPaciente());
        }

        Paciente pacienteActualizado = pacienteRepository.save(pacienteExistente);
        return convertirA_ResponseDTO(pacienteActualizado);
    }

    // --- MAPPERS (Conversión DTO <--> Entidad) ---
    
    // Convierte Entidad a DTO de Respuesta
    private PacienteResponseDTO convertirA_ResponseDTO(Paciente paciente) {
        PacienteResponseDTO dto = new PacienteResponseDTO();
        dto.setIdPaciente(paciente.getIdPaciente());
        // Incluir el ID de usuario si es necesario en la respuesta: dto.setIdUsuario(paciente.getIdUsuario()); 
        dto.setDniPaciente(paciente.getDniPaciente());
        dto.setNomPaciente(paciente.getNomPaciente());
        dto.setApPaciente(paciente.getApPaciente());
        dto.setAmPaciente(paciente.getAmPaciente());
        dto.setEmailPaciente(paciente.getEmailPaciente());
        dto.setFnPaciente(paciente.getFnPaciente());
        dto.setTelfPaciente(paciente.getTelfPaciente()); // CAMPO AGREGADO EN RESPONSE
        return dto;
    }

    // Convierte DTO de Request a Entidad
    private Paciente convertirA_Entidad(PacienteRequestDTO requestDTO) {
        Paciente paciente = new Paciente();
        // NOTA: No asignamos idUsuario aquí, eso se maneja en el AuthService o en un servicio dedicado a perfiles.
        paciente.setDniPaciente(requestDTO.getDniPaciente());
        paciente.setNomPaciente(requestDTO.getNomPaciente());
        paciente.setApPaciente(requestDTO.getApPaciente());
        paciente.setAmPaciente(requestDTO.getAmPaciente());
        paciente.setEmailPaciente(requestDTO.getEmailPaciente());
        paciente.setFnPaciente(requestDTO.getFnPaciente());
        paciente.setTelfPaciente(requestDTO.getTelfPaciente()); // CAMPO AGREGADO EN ENTITY
        return paciente;
    }
}