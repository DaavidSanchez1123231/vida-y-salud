package pe.com.VidaySalud.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import pe.com.VidaySalud.dto.DashboardStatsDTO;
import pe.com.VidaySalud.service.StatsService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/stats")
public class StatsController {

    @Autowired
    private StatsService statsService;

    @GetMapping("/dashboard")
    @PreAuthorize("hasAuthority('ROL_ADMIN')") // ¡SOLO ADMIN!
    public DashboardStatsDTO getDashboardStats() {
        return statsService.getDashboardStats();
    }
}