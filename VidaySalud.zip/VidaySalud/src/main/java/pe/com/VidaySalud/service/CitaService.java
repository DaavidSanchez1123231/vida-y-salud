package pe.com.VidaySalud.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.com.VidaySalud.dto.CitaRequestDTO;
import pe.com.VidaySalud.dto.CitaResponseDTO;
import pe.com.VidaySalud.exception.BusinessConflictException;
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Cita; 
import pe.com.VidaySalud.repository.CitaRepository;
import pe.com.VidaySalud.repository.MedicoRepository;
import pe.com.VidaySalud.repository.PacienteRepository;

@Service
public class CitaService {

    @Autowired private CitaRepository citaRepository;
    @Autowired private HorarioService horarioService; 
    @Autowired private PacienteRepository pacienteRepository;
    @Autowired private MedicoRepository medicoRepository;
    
    // -----------------------------------------------------------------------
    // MÉTODOS DE TRANSACCIÓN CRÍTICA
    // -----------------------------------------------------------------------

    @Transactional
    public CitaResponseDTO crearCita(CitaRequestDTO requestDTO) {
        
        // 1. VERIFICACIÓN DE EXISTENCIA DE ENTIDADES (Usando repositorios)
        if (!pacienteRepository.existsById(requestDTO.getIdPaciente())) {
            throw new ResourceNotFoundException("Paciente no encontrado con ID: " + requestDTO.getIdPaciente());
        }
        if (!medicoRepository.existsById(requestDTO.getIdMedico())) {
            throw new ResourceNotFoundException("Médico no encontrado con ID: " + requestDTO.getIdMedico());
        }

        // 2. VERIFICACIÓN DE DISPONIBILIDAD (Usa HorarioService)
        
        LocalDateTime fechaHoraCompleta = requestDTO.getFechaHora();
        LocalTime horaCita = fechaHoraCompleta.toLocalTime();
        LocalDate fechaCita = fechaHoraCompleta.toLocalDate();
        
        List<String> slotsDisponibles = horarioService.obtenerHorariosDisponibles(
            requestDTO.getIdMedico(), 
            fechaCita
        );
        
        String horaSolicitada = horaCita.truncatedTo(ChronoUnit.MINUTES).toString(); 

        if (!slotsDisponibles.contains(horaSolicitada)) {
            throw new BusinessConflictException("El horario solicitado (" + horaSolicitada + " el " + fechaCita + ") no está disponible.");
        }
        
        // 3. CREAR Y GUARDAR CITA
        Cita nuevaCita = convertirA_Entidad(requestDTO); 
        
        if (nuevaCita.getEstado() == null || nuevaCita.getEstado().isEmpty()) {
            nuevaCita.setEstado("PENDIENTE");
        }
        
        Cita citaGuardada = citaRepository.save(nuevaCita);
        return convertirA_ResponseDTO(citaGuardada);
    }
    
    @Transactional
    public CitaResponseDTO reprogramarCita(Integer idCita, LocalDateTime nuevaFechaHora) {
        Cita citaExistente = citaRepository.findById(idCita)
            .orElseThrow(() -> new ResourceNotFoundException("Cita no encontrada con ID: " + idCita));

        // 1. Verificar si el nuevo horario está disponible
        LocalTime nuevaHora = nuevaFechaHora.toLocalTime();
        LocalDate nuevaFecha = nuevaFechaHora.toLocalDate();
        
        List<String> slotsDisponibles = horarioService.obtenerHorariosDisponibles(
            citaExistente.getIdMedico(), // Usamos el ID de la entidad directamente
            nuevaFecha
        );

        String horaSolicitada = nuevaHora.truncatedTo(ChronoUnit.MINUTES).toString();
        
        if (!slotsDisponibles.contains(horaSolicitada)) {
            throw new BusinessConflictException("El nuevo horario no está disponible para el médico.");
        }

        // 2. Actualizar y guardar
        citaExistente.setFechaHora(nuevaFechaHora);
        citaExistente.setEstado("REPROGRAMADA");
        
        Cita citaActualizada = citaRepository.save(citaExistente);
        return convertirA_ResponseDTO(citaActualizada);
    }

    // -----------------------------------------------------------------------
    // MÉTODOS DE GESTIÓN Y CONSULTA
    // -----------------------------------------------------------------------

    public List<CitaResponseDTO> obtenerTodasLasCitas() {
        return citaRepository.findAll().stream()
            .map(this::convertirA_ResponseDTO)
            .collect(Collectors.toList());
    }

    public CitaResponseDTO obtenerCitaPorId(Integer id) {
        Cita cita = citaRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Cita no encontrada con ID: " + id));
        return convertirA_ResponseDTO(cita);
    }

    public List<CitaResponseDTO> obtenerCitasPorPaciente(Integer idPaciente) {
        List<Cita> citas = citaRepository.findByIdPaciente(idPaciente); 
        return citas.stream().map(this::convertirA_ResponseDTO).collect(Collectors.toList());
    }
    
    public List<CitaResponseDTO> obtenerCitasPorMedico(Integer idMedico) {
        List<Cita> citas = citaRepository.findByIdMedico(idMedico); 
        return citas.stream().map(this::convertirA_ResponseDTO).collect(Collectors.toList());
    }
    public CitaResponseDTO cambiarEstadoCita(Integer idCita, String nuevoEstado) {
        Cita citaExistente = citaRepository.findById(idCita)
            .orElseThrow(() -> new ResourceNotFoundException("Cita no encontrada con ID: " + idCita));
            
        if (citaExistente.getEstado().equals("COMPLETADA") || citaExistente.getEstado().equals("CANCELADA")) {
             throw new BusinessConflictException("La cita ya está en estado final y no puede modificarse.");
        }
        
        citaExistente.setEstado(nuevoEstado);
        Cita citaActualizada = citaRepository.save(citaExistente);
        return convertirA_ResponseDTO(citaActualizada);
    }
    public List<CitaResponseDTO> obtenerCitasPorPacienteYRango(Integer idPaciente, LocalDateTime inicio, LocalDateTime fin) {
        
        
        List<Cita> citas = citaRepository.findByPacienteAndDateRange(idPaciente, inicio, fin); 
        
        return citas.stream().map(this::convertirA_ResponseDTO).collect(Collectors.toList());
    }

    @Transactional
    public void eliminarCita(Integer id) {
        if (!citaRepository.existsById(id)) {
            throw new ResourceNotFoundException("Cita no encontrada con ID: " + id);
        }
        citaRepository.deleteById(id);
    }
    
    // -----------------------------------------------------------------------
    // MAPPERS (CORREGIDOS PARA USAR SHADOW IDs)
    // -----------------------------------------------------------------------
    
    private Cita convertirA_Entidad(CitaRequestDTO dto) {
        Cita cita = new Cita();
        
        // Aquí NO buscamos Medico/Paciente, usamos los IDs directamente (Shadow IDs)
        cita.setIdMedico(dto.getIdMedico());
        cita.setIdPaciente(dto.getIdPaciente());
        
        cita.setFechaHora(dto.getFechaHora());
        cita.setMotivoConsulta(dto.getMotivoConsulta());
        cita.setEstado(dto.getEstado()); 
        
        return cita;
    }
    
    private CitaResponseDTO convertirA_ResponseDTO(Cita cita) {
        CitaResponseDTO dto = new CitaResponseDTO();
        
        // Mapeo básico de campos
        dto.setIdCita(cita.getIdCita());
        dto.setFechaHora(cita.getFechaHora());
        dto.setEstado(cita.getEstado());
        dto.setMotivoConsulta(cita.getMotivoConsulta());

        // Mapeo de IDs (Usamos los getters de ID de la entidad Cita)
        dto.setIdMedico(cita.getIdMedico());
        dto.setIdPaciente(cita.getIdPaciente());
        
        return dto;
    }
}