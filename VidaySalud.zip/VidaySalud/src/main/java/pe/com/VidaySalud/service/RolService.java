package pe.com.VidaySalud.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.VidaySalud.dto.RolDTO; // Importar DTO
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Rol;
import pe.com.VidaySalud.repository.RolRepository;

@Service
public class RolService {

    @Autowired
    private RolRepository rolRepository;

    public List<RolDTO> obtenerTodosLosRoles() {
        return rolRepository.findAll()
                .stream()
                .map(this::convertirA_DTO)
                .collect(Collectors.toList());
    }

    public RolDTO crearRol(RolDTO dto) {
        Rol rol = convertirA_Entidad(dto);
        Rol rolGuardado = rolRepository.save(rol);
        return convertirA_DTO(rolGuardado);
    }
    
    public RolDTO obtenerRolPorId(Integer id) {
        Rol rol = rolRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Rol no encontrado con ID: " + id));
        return convertirA_DTO(rol);
    }

    public void eliminarRol(Integer id) {
        if (!rolRepository.existsById(id)) {
            throw new ResourceNotFoundException("Rol no encontrado con ID: " + id);
        }
        rolRepository.deleteById(id);
    }


    
    private RolDTO convertirA_DTO(Rol rol) {
        RolDTO dto = new RolDTO();
        dto.setIdRol(rol.getIdRol());
        dto.setNomRol(rol.getNomRol());
        return dto;
    }

    private Rol convertirA_Entidad(RolDTO dto) {
        Rol rol = new Rol();
        rol.setNomRol(dto.getNomRol());
        return rol;
    }
    public RolDTO actualizarRol(Integer id, RolDTO dto) {
        Rol rol = rolRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Rol no encontrado con ID: " + id));
        

        rol.setNomRol(dto.getNomRol());
        
        Rol actualizado = rolRepository.save(rol);
        return convertirA_DTO(actualizado);
    }

    public RolDTO actualizarRolParcial(Integer id, RolDTO dto) {
        Rol rol = rolRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Rol no encontrado con ID: " + id));
        

        if (dto.getNomRol() != null) {
            rol.setNomRol(dto.getNomRol());
        }
        
        Rol actualizado = rolRepository.save(rol);
        return convertirA_DTO(actualizado);
    }
}