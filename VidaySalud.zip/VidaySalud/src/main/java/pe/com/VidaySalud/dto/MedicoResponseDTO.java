package pe.com.VidaySalud.dto;

import lombok.Data;

@Data
public class MedicoResponseDTO {

    private Integer idMedico;
    private Integer idEspecialidad;
    private Integer idUsuario;
    private String codMedico;
    private String monMedico;
    private String apMedico;
    private String amMedico;
    private String estMedico;
    private String urlFoto;
    
	public String getUrlFoto() {
		return urlFoto;
	}
	public void setUrlFoto(String urlFoto) {
		this.urlFoto = urlFoto;
	}
	public Integer getIdMedico() {
		return idMedico;
	}
	public void setIdMedico(Integer idMedico) {
		this.idMedico = idMedico;
	}
	public Integer getIdEspecialidad() {
		return idEspecialidad;
	}
	public void setIdEspecialidad(Integer idEspecialidad) {
		this.idEspecialidad = idEspecialidad;
	}
	public Integer getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	public String getCodMedico() {
		return codMedico;
	}
	public void setCodMedico(String codMedico) {
		this.codMedico = codMedico;
	}
	public String getMonMedico() {
		return monMedico;
	}
	public void setMonMedico(String monMedico) {
		this.monMedico = monMedico;
	}
	public String getApMedico() {
		return apMedico;
	}
	public void setApMedico(String apMedico) {
		this.apMedico = apMedico;
	}
	public String getAmMedico() {
		return amMedico;
	}
	public void setAmMedico(String amMedico) {
		this.amMedico = amMedico;
	}
	public String getEstMedico() {
		return estMedico;
	}
	public void setEstMedico(String estMedico) {
		this.estMedico = estMedico;
	}
    
    
}