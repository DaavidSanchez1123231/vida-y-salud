package pe.com.VidaySalud.rest;

import java.time.LocalDate;
import java.time.LocalDateTime; // Necesario para el endpoint de citas, aunque no se usa aquí.
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import pe.com.VidaySalud.dto.DisponibilidadRequestDTO;
// CRÍTICO: Importación necesaria para el retorno del método
import pe.com.VidaySalud.dto.DisponibilidadResponseDTO; 
import pe.com.VidaySalud.service.HorarioService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/horarios")
public class HorarioController {

    @Autowired
    private HorarioService horarioService;


    @GetMapping("/disponible")
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'ROL_RECEPCIONISTA', 'PACIENTE')")
    public List<String> obtenerHorariosDisponibles(
        @RequestParam Integer idMedico,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fecha) 
    {
        return horarioService.obtenerHorariosDisponibles(idMedico, fecha);
    }
    
    // --- 2. GET: LISTAR HORARIOS REGISTRADOS ---
    @GetMapping("/medico")
    @PreAuthorize("hasAnyAuthority('ROL_MEDICO', 'ROL_ADMIN')")
    // El error estaba aquí porque faltaba la importación de DisponibilidadResponseDTO
    public List<DisponibilidadResponseDTO> obtenerHorariosRegistrados(@RequestParam Integer idMedico) {
        return horarioService.obtenerHorariosRegistradosPorMedico(idMedico);
    }

    // --- 3. POST: REGISTRAR NUEVO HORARIO ---
    @PostMapping("/medico")
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAnyAuthority('ROL_MEDICO', 'ROL_ADMIN')")
    public void registrarDisponibilidad(@RequestBody DisponibilidadRequestDTO request) {
        horarioService.registrarDisponibilidad(request); 
    }
}