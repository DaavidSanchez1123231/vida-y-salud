package pe.com.VidaySalud.dto;

import java.time.LocalDate;

import lombok.Data;

@Data
public class PacienteResponseDTO {

    private Integer idPaciente;
    private String dniPaciente;
    private String nomPaciente;
    private String apPaciente;
    private String amPaciente;
    private String emailPaciente;
    private LocalDate fnPaciente; 
    private String telfPaciente;
	public Integer getIdPaciente() {
		return idPaciente;
	}
	public void setIdPaciente(Integer idPaciente) {
		this.idPaciente = idPaciente;
	}
	public String getDniPaciente() {
		return dniPaciente;
	}
	public void setDniPaciente(String dniPaciente) {
		this.dniPaciente = dniPaciente;
	}
	public String getNomPaciente() {
		return nomPaciente;
	}
	public void setNomPaciente(String nomPaciente) {
		this.nomPaciente = nomPaciente;
	}
	public String getApPaciente() {
		return apPaciente;
	}
	public void setApPaciente(String apPaciente) {
		this.apPaciente = apPaciente;
	}
	public String getAmPaciente() {
		return amPaciente;
	}
	public void setAmPaciente(String amPaciente) {
		this.amPaciente = amPaciente;
	}
	public String getEmailPaciente() {
		return emailPaciente;
	}
	public void setEmailPaciente(String emailPaciente) {
		this.emailPaciente = emailPaciente;
	}
	public LocalDate getFnPaciente() {
		return fnPaciente;
	}
	public void setFnPaciente(LocalDate fnPaciente) {
		this.fnPaciente = fnPaciente;
	}
	public String getTelfPaciente() {
		return telfPaciente;
	}
	public void setTelfPaciente(String telfPaciente) {
		this.telfPaciente = telfPaciente;
	}
	
    
}