package pe.com.VidaySalud.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import pe.com.VidaySalud.model.Cita;
import pe.com.VidaySalud.model.Paciente; // Necesitamos esto
import pe.com.VidaySalud.repository.CitaRepository;
import pe.com.VidaySalud.repository.PacienteRepository; // Necesitamos esto

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Service
public class ScheduledTaskService {

    @Autowired
    private CitaRepository citaRepository;

    @Autowired
    private PacienteRepository pacienteRepository; // Para buscar el email del paciente

    @Autowired
    private EmailService emailService; // El servicio que ya creamos

    /**
     * Tarea programada para enviar recordatorios de citas (RF4).
     * Se ejecuta todos los días a las 7:00 AM.
     * Cron: (segundo minuto hora día-del-mes mes día-de-la-semana)
     * "0 0 7 * * ?" = 0 segundos, 0 minutos, hora 7, todos los días, todos los meses.
     */
    @Scheduled(cron = "0 0 7 * * ?")
    public void sendAppointmentReminders() {
        System.out.println("--- EJECUTANDO TAREA PROGRAMADA: Enviar Recordatorios (7:00 AM) ---");

        // 1. Definir el rango de "mañana"
        LocalDate manana = LocalDate.now().plusDays(1);
        LocalDateTime inicioDeManana = manana.atStartOfDay(); // Mañana a las 00:00:00
        LocalDateTime finDeManana = manana.atTime(23, 59, 59); // Mañana a las 23:59:59

        // 2. Buscar todas las citas de mañana (usando el método que añadimos al repo)
        List<Cita> citasDeManana = citaRepository.findByFechaHoraBetween(inicioDeManana, finDeManana);

        System.out.println("Citas encontradas para mañana: " + citasDeManana.size());

        for (Cita cita : citasDeManana) {
            
            // Solo enviar recordatorio si la cita sigue 'PROGRAMADA'
            if (cita.getEstado() != null && cita.getEstado().equalsIgnoreCase("PROGRAMADA")) {
                
                try {
                    // 3. Buscar al paciente para obtener su email y nombre
                    Paciente paciente = pacienteRepository.findById(cita.getIdPaciente())
                        .orElseThrow(() -> new RuntimeException("Paciente no encontrado para la cita ID: " + cita.getIdCita()));
                    
                    if (paciente.getEmailPaciente() != null && !paciente.getEmailPaciente().isEmpty()) {
                        
                        // 4. Formatear y enviar el email
                        String emailDestino = paciente.getEmailPaciente();
                        String asunto = "Recordatorio de Cita - Clínica Salud y Vida";
                        String cuerpoMensaje = construirMensajeEmail(paciente, cita);
                        
                        emailService.sendSimpleMessage(emailDestino, asunto, cuerpoMensaje);
                    }
                } catch (Exception e) {
                    // Captura errores (ej. paciente no encontrado) para que el bucle continúe
                    System.err.println("Error procesando recordatorio para cita ID " + cita.getIdCita() + ": " + e.getMessage());
                }
            }
        }
        System.out.println("--- TAREA PROGRAMADA: Finalizada ---");
    }

    /**
     * Helper para construir el texto del correo
     */
    private String construirMensajeEmail(Paciente paciente, Cita cita) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy 'a las' HH:mm 'horas'");
        String fechaHoraFormateada = cita.getFechaHora().format(formatter);
        
        // (Eventualmente, puedes mejorar esto para buscar el nombre del médico)
        
        return String.format(
            "Hola %s %s,\n\n" +
            "Este es un recordatorio de su cita en la Clínica Salud y Vida.\n\n" +
            "Fecha y Hora: %s\n" +
            "Médico: (ID: %d)\n\n" + 
            "Por favor, llegue 10 minutos antes.\n" +
            "Si no puede asistir, contáctenos para reprogramar.\n\n" +
            "Gracias,\n" +
            "Clínica Salud y Vida",
            
            paciente.getNomPaciente(),
            paciente.getApPaciente(),
            fechaHoraFormateada,
            cita.getIdMedico()
        );
    }
}