package pe.com.VidaySalud.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import pe.com.VidaySalud.dto.EspecialidadDTO; // Importar DTO
import pe.com.VidaySalud.service.EspecialidadService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/especialidades")
public class EspecialidadController {

    @Autowired
    private EspecialidadService especialidadService;

    @GetMapping
    public List<EspecialidadDTO> obtenerTodas() {
        return especialidadService.obtenerTodasLasEspecialidades();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EspecialidadDTO crear(@RequestBody EspecialidadDTO especialidadDTO) {
        return especialidadService.crearEspecialidad(especialidadDTO);
    }

    @GetMapping("/{id}")
    public EspecialidadDTO obtenerPorId(@PathVariable Integer id) {
        return especialidadService.obtenerEspecialidadPorId(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // 204 No Content
    public void eliminar(@PathVariable Integer id) {
        especialidadService.eliminarEspecialidad(id);
    }
    @PutMapping("/{id}")
    public EspecialidadDTO actualizar(@PathVariable Integer id, @RequestBody EspecialidadDTO especialidadDTO) {
        return especialidadService.actualizarEspecialidad(id, especialidadDTO);
    }

    @PatchMapping("/{id}")
    public EspecialidadDTO actualizarParcial(@PathVariable Integer id, @RequestBody EspecialidadDTO especialidadDTO) {
        return especialidadService.actualizarEspecialidadParcial(id, especialidadDTO);
    }
}