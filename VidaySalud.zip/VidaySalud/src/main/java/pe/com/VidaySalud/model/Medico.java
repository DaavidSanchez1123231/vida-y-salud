package pe.com.VidaySalud.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "medico")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Medico {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_medico")
    private Integer idMedico;


    @Column(name = "id_especialidad", nullable = false)
    private Integer idEspecialidad;

    @Column(name = "id_usuario", nullable = false)
    private Integer idUsuario;



    @Column(name = "cod_medico", nullable = false)
    private String codMedico;

    @Column(name = "mon_medico", nullable = false)
    private String monMedico;

    @Column(name = "ap_medico", nullable = false)
    private String apMedico;

    @Column(name = "am_medico", nullable = false)
    private String amMedico;

    @Column(name = "est_medico", nullable = false)
    private String estMedico;

    @Column(name = "url_foto", nullable = true)
    private String urlFoto;

    // Getter y Setter
    public String getUrlFoto() { 
    	return urlFoto; 
    	}
    public void setUrlFoto(String urlFoto) { 
    	this.urlFoto = urlFoto; 
    	}
    

	public Integer getIdMedico() {
		return idMedico;
	}

	public void setIdMedico(Integer idMedico) {
		this.idMedico = idMedico;
	}

	public Integer getIdEspecialidad() {
		return idEspecialidad;
	}

	public void setIdEspecialidad(Integer idEspecialidad) {
		this.idEspecialidad = idEspecialidad;
	}

	public Integer getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getCodMedico() {
		return codMedico;
	}

	public void setCodMedico(String codMedico) {
		this.codMedico = codMedico;
	}

	public String getMonMedico() {
		return monMedico;
	}

	public void setMonMedico(String monMedico) {
		this.monMedico = monMedico;
	}

	public String getApMedico() {
		return apMedico;
	}

	public void setApMedico(String apMedico) {
		this.apMedico = apMedico;
	}

	public String getAmMedico() {
		return amMedico;
	}

	public void setAmMedico(String amMedico) {
		this.amMedico = amMedico;
	}

	public String getEstMedico() {
		return estMedico;
	}

	public void setEstMedico(String estMedico) {
		this.estMedico = estMedico;
	}

}