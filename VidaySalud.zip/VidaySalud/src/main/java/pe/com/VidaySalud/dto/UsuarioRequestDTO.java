package pe.com.VidaySalud.dto;

import lombok.Data;

@Data
public class UsuarioRequestDTO {
    
    private Integer idRol;
    private String emilUsuario; 
    private String passwordUsuario;
	public Integer getIdRol() {
		return idRol;
	}
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}
	public String getEmilUsuario() {
		return emilUsuario;
	}
	public void setEmilUsuario(String emilUsuario) {
		this.emilUsuario = emilUsuario;
	}
	public String getPasswordUsuario() {
		return passwordUsuario;
	}
	public void setPasswordUsuario(String passwordUsuario) {
		this.passwordUsuario = passwordUsuario;
	}
    
}