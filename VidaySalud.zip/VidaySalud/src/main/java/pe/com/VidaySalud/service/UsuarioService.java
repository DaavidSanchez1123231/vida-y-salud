package pe.com.VidaySalud.service;

import java.util.List;
import java.util.stream.Collectors; 
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.password.PasswordEncoder;

import pe.com.VidaySalud.dto.UsuarioRequestDTO;
import pe.com.VidaySalud.dto.UsuarioResponseDTO;
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Usuario;
import pe.com.VidaySalud.model.Rol; 
import pe.com.VidaySalud.repository.UsuarioRepository;
import pe.com.VidaySalud.repository.RolRepository; 

@Service
public class UsuarioService {

    @Autowired
    private UsuarioRepository usuarioRepository;
    
    @Autowired
    private RolRepository rolRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<UsuarioResponseDTO> obtenerTodosLosUsuarios() {
        return usuarioRepository.findAll().stream()
                .map(this::convertirA_ResponseDTO) 
                .collect(Collectors.toList());
    }

    public UsuarioResponseDTO crearUsuario(UsuarioRequestDTO requestDTO) {
        // Llama al nuevo mapper
        Usuario nuevoUsuario = convertirA_Entidad(requestDTO);
        
        String passwordEncriptada = passwordEncoder.encode(requestDTO.getPasswordUsuario());
        nuevoUsuario.setPasswordUsuario(passwordEncriptada);
        
        Usuario usuarioGuardado = usuarioRepository.save(nuevoUsuario);
        return convertirA_ResponseDTO(usuarioGuardado);
    }
    
    public UsuarioResponseDTO obtenerUsuarioPorId(Integer id) {
        Usuario usuario = usuarioRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con ID: " + id));
        return convertirA_ResponseDTO(usuario);
    }

    public void eliminarUsuario(Integer id) {
        if (!usuarioRepository.existsById(id)) {
            throw new ResourceNotFoundException("Usuario no encontrado con ID: " + id);
        }
        usuarioRepository.deleteById(id);
    }
    
    public UsuarioResponseDTO actualizarUsuario(Integer id, UsuarioRequestDTO requestDTO) {
        Usuario usuario = usuarioRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con ID: " + id));

        // Busca el Rol completo usando el ID del DTO
        Rol rol = rolRepository.findById(requestDTO.getIdRol())
            .orElseThrow(() -> new ResourceNotFoundException("Rol no encontrado con ID: " + requestDTO.getIdRol()));
        usuario.setRol(rol); // Asigna el objeto Rol
        
        // CORREGIDO: setEmailUsuario
        usuario.setEmailUsuario(requestDTO.getEmilUsuario());
        
        if (requestDTO.getPasswordUsuario() != null && !requestDTO.getPasswordUsuario().isEmpty()) {
             usuario.setPasswordUsuario(passwordEncoder.encode(requestDTO.getPasswordUsuario()));
        }
        Usuario actualizado = usuarioRepository.save(usuario);
        return convertirA_ResponseDTO(actualizado);
    }

    public UsuarioResponseDTO actualizarUsuarioParcial(Integer id, UsuarioRequestDTO requestDTO) {
        Usuario usuario = usuarioRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con ID: " + id));

        if (requestDTO.getIdRol() != null) {
            Rol rol = rolRepository.findById(requestDTO.getIdRol())
                .orElseThrow(() -> new ResourceNotFoundException("Rol no encontrado con ID: " + requestDTO.getIdRol()));
            usuario.setRol(rol); 
        }
        
        if (requestDTO.getEmilUsuario() != null) {
            // CORREGIDO: setEmailUsuario
            usuario.setEmailUsuario(requestDTO.getEmilUsuario());
        }
        
        if (requestDTO.getPasswordUsuario() != null && !requestDTO.getPasswordUsuario().isEmpty()) {
            usuario.setPasswordUsuario(passwordEncoder.encode(requestDTO.getPasswordUsuario()));
        }
        
        Usuario actualizado = usuarioRepository.save(usuario);
        return convertirA_ResponseDTO(actualizado);
    }

    // --- Mapeadores (ACTUALIZADOS) ---

    /**
     * Convierte de Entidad (con objeto Rol) a DTO (con idRol)
     */
    private UsuarioResponseDTO convertirA_ResponseDTO(Usuario usuario) {
        UsuarioResponseDTO dto = new UsuarioResponseDTO();
        dto.setIdUsuario(usuario.getIdUsuario());
        // Ahora obtenemos el ID desde el objeto Rol
        dto.setIdRol(usuario.getRol().getIdRol()); 
        
        // CORREGIDO: getEmailUsuario (El getter de la entidad ya fue corregido)
        dto.setEmilUsuario(usuario.getEmailUsuario());
        
        return dto;
    }
    
    /**
     * Convierte de DTO (con idRol) a Entidad (con objeto Rol)
     */
    private Usuario convertirA_Entidad(UsuarioRequestDTO requestDTO) {
        Usuario usuario = new Usuario();
        
        Rol rol = rolRepository.findById(requestDTO.getIdRol())
            .orElseThrow(() -> new ResourceNotFoundException("No se puede crear usuario. Rol no encontrado con ID: " + requestDTO.getIdRol()));
        usuario.setRol(rol); 
        
        // CORREGIDO: setEmailUsuario
        usuario.setEmailUsuario(requestDTO.getEmilUsuario());
        
        usuario.setPasswordUsuario(requestDTO.getPasswordUsuario()); 
        return usuario;
    }
}