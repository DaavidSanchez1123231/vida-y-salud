package pe.com.VidaySalud.dto;

import java.time.LocalDate;
import org.springframework.format.annotation.DateTimeFormat;
import lombok.Data; // Assuming Lombok is installed for @Data

// Note: If Lombok is not correctly installed, you must include ALL the Getters and Setters 
// that were manually written in the previous versions.

public class RegisterRequestDTO {

    // --- DATOS DE USUARIO (Acceso) ---
    private String emilUsuario;
    private String passwordUsuario;
    
    // --- DATOS DE PACIENTE (Perfil) ---
    private String dniPaciente;
    private String nomPaciente;
    private String apPaciente;
    private String amPaciente; 
    
    // CRÍTICO: Anotación para parsear la fecha YYYY-MM-DD del frontend a LocalDate
    @DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate fnPaciente; 
    
    // CAMPO AGREGADO: Teléfono de contacto
    private String telefono;
    
    // --- Getters y Setters ---

    public String getEmilUsuario() { return emilUsuario; }
    public void setEmilUsuario(String emilUsuario) { this.emilUsuario = emilUsuario; }

    public String getPasswordUsuario() { return passwordUsuario; }
    public void setPasswordUsuario(String passwordUsuario) { this.passwordUsuario = passwordUsuario; }

    public String getDniPaciente() { return dniPaciente; }
    public void setDniPaciente(String dniPaciente) { this.dniPaciente = dniPaciente; }

    public String getNomPaciente() { return nomPaciente; }
    public void setNomPaciente(String nomPaciente) { this.nomPaciente = nomPaciente; }

    public String getApPaciente() { return apPaciente; }
    public void setApPaciente(String apPaciente) { this.apPaciente = apPaciente; }

    public String getAmPaciente() { return amPaciente; }
    public void setAmPaciente(String amPaciente) { this.amPaciente = amPaciente; }

    public LocalDate getFnPaciente() { return fnPaciente; }
    public void setFnPaciente(LocalDate fnPaciente) { this.fnPaciente = fnPaciente; }

    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
}