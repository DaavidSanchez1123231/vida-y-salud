package pe.com.VidaySalud.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import pe.com.VidaySalud.dto.RolDTO; // Importar DTO
import pe.com.VidaySalud.service.RolService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/roles")
public class RolController {

    @Autowired
    private RolService rolService;

    @GetMapping
    public List<RolDTO> obtenerTodos() {
        return rolService.obtenerTodosLosRoles();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public RolDTO crear(@RequestBody RolDTO rolDTO) {
        return rolService.crearRol(rolDTO);
    }

    @GetMapping("/{id}")
    public RolDTO obtenerPorId(@PathVariable Integer id) {
        return rolService.obtenerRolPorId(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // 204 No Content
    public void eliminar(@PathVariable Integer id) {
        rolService.eliminarRol(id);
    }
    @PutMapping("/{id}")
    public RolDTO actualizar(@PathVariable Integer id, @RequestBody RolDTO rolDTO) {
        return rolService.actualizarRol(id, rolDTO);
    }

    @PatchMapping("/{id}")
    public RolDTO actualizarParcial(@PathVariable Integer id, @RequestBody RolDTO rolDTO) {
        return rolService.actualizarRolParcial(id, rolDTO);
    }
}