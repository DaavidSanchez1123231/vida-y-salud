package pe.com.VidaySalud.model;

import java.time.LocalDate;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "paciente")
public class Paciente {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_paciente")
    private Integer idPaciente;

    // Shadow ID que lo enlaza a la tabla Usuario
    @Column(name = "id_usuario", nullable = false, unique = true)
    private Integer idUsuario; 

    @Column(name = "dni_paciente", nullable = false, unique = true, length = 8)
    private String dniPaciente;

    @Column(name = "nom_paciente", nullable = false)
    private String nomPaciente;

    @Column(name = "ap_paciente", nullable = false)
    private String apPaciente;

    @Column(name = "am_paciente", nullable = false)
    private String amPaciente;
    
    @Column(name = "email_paciente", nullable = false)
    private String emailPaciente;

    @Column(name = "fn_paciente", nullable = false)
    private LocalDate fnPaciente;
    
    // Campo AGREGADO: Teléfono de contacto
    @Column(name = "telf_paciente", nullable = true, length = 9)
    private String telfPaciente; 

    // --- Getters y Setters ---

    public Integer getIdPaciente() { return idPaciente; }
    public void setIdPaciente(Integer idPaciente) { this.idPaciente = idPaciente; }

    public Integer getIdUsuario() { return idUsuario; }
    public void setIdUsuario(Integer idUsuario) { this.idUsuario = idUsuario; }

    public String getDniPaciente() { return dniPaciente; }
    public void setDniPaciente(String dniPaciente) { this.dniPaciente = dniPaciente; }

    public String getNomPaciente() { return nomPaciente; }
    public void setNomPaciente(String nomPaciente) { this.nomPaciente = nomPaciente; }

    public String getApPaciente() { return apPaciente; }
    public void setApPaciente(String apPaciente) { this.apPaciente = apPaciente; }

    public String getAmPaciente() { return amPaciente; }
    public void setAmPaciente(String amPaciente) { this.amPaciente = amPaciente; }

    public String getEmailPaciente() { return emailPaciente; }
    public void setEmailPaciente(String emailPaciente) { this.emailPaciente = emailPaciente; }

    public LocalDate getFnPaciente() { return fnPaciente; }
    public void setFnPaciente(LocalDate fnPaciente) { this.fnPaciente = fnPaciente; }

    public String getTelfPaciente() { return telfPaciente; }
    public void setTelfPaciente(String telfPaciente) { this.telfPaciente = telfPaciente; }
}