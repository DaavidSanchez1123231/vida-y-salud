package pe.com.VidaySalud.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import pe.com.VidaySalud.dto.AuthLoginRequestDTO;
import pe.com.VidaySalud.dto.AuthLoginResponseDTO;
import pe.com.VidaySalud.dto.RegisterRequestDTO;
import pe.com.VidaySalud.service.AuthService;

@RestController
@RequestMapping("/auth") // CORRECCIÓN: Usamos /auth para las rutas de autenticación
public class AuthController {

    @Autowired
    private AuthService authService;

    // POST /auth/login
    @PostMapping("/login")
    public ResponseEntity<AuthLoginResponseDTO> login(@RequestBody AuthLoginRequestDTO request) {
        return ResponseEntity.ok(authService.login(request));
    }

    // POST /auth/registrarPaciente
    // CORRECCIÓN CRÍTICA: Mapeamos el endpoint correctamente.
    @PostMapping("/registrarPaciente") 
    public ResponseEntity<AuthLoginResponseDTO> registrarPaciente(@RequestBody RegisterRequestDTO request) {
        return ResponseEntity.ok(authService.registrarPaciente(request));
    }
}