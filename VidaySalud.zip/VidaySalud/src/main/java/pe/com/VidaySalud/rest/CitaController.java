package pe.com.VidaySalud.rest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize; 
import org.springframework.web.bind.annotation.*;
import org.springframework.format.annotation.DateTimeFormat;
import java.time.LocalDateTime;
import java.util.List;

import pe.com.VidaySalud.dto.CitaRequestDTO;
import pe.com.VidaySalud.dto.CitaResponseDTO;
import pe.com.VidaySalud.service.CitaService;

@RestController
@CrossOrigin(origins = "*") 
@RequestMapping("/api/citas")
public class CitaController {

    @Autowired
    private CitaService citaService;

    // --- 1. GET: CONSULTA GENERAL (Admin) ---
    @GetMapping
    @PreAuthorize("hasAuthority('ROL_ADMIN')") 
    public List<CitaResponseDTO> obtenerTodas() {
        return citaService.obtenerTodasLasCitas();
    }

    // --- 2. GET: PARA PACIENTE/MÉDICO (Consulta Básica) ---
    @GetMapping("/paciente/{idPaciente}")
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'PACIENTE')")
    public List<CitaResponseDTO> obtenerPorPaciente(@PathVariable Integer idPaciente) {
        return citaService.obtenerCitasPorPaciente(idPaciente);
    }
    
    // --- 3. GET: CONSULTA POR RANGO (El endpoint FALTANTE que el frontend llama) ---
    @GetMapping("/paciente/rango")
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'PACIENTE')")
    public List<CitaResponseDTO> obtenerPorPacienteYRango(
        @RequestParam Integer idPaciente,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime start,
        @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime end)
    {
        return citaService.obtenerCitasPorPacienteYRango(idPaciente, start, end);
    }
    
    @GetMapping("/medico/{idMedico}")
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'ROL_MEDICO')")
    public List<CitaResponseDTO> obtenerPorMedico(@PathVariable Integer idMedico) {
        return citaService.obtenerCitasPorMedico(idMedico);
    }

    @GetMapping("/{id}")
    @PreAuthorize("isAuthenticated()")
    public CitaResponseDTO obtenerPorId(@PathVariable Integer id) {
        return citaService.obtenerCitaPorId(id);
    }
    
    // --- 4. POST: CREAR CITA (Recepcionista/Paciente) ---
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) 
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'ROL_RECEPCIONISTA', 'PACIENTE')")
    public CitaResponseDTO crear(@RequestBody CitaRequestDTO citaRequestDTO) {
        return citaService.crearCita(citaRequestDTO);
    }

    // --- 5. PUT: GESTIÓN DE ESTADO ---
    
    @PutMapping("/{id}/cancelar")
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'ROL_RECEPCIONISTA', 'PACIENTE')")
    public CitaResponseDTO cancelarCita(@PathVariable Integer id) {
        return citaService.cambiarEstadoCita(id, "CANCELADA");
    }

    @PutMapping("/{id}/completar")
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'ROL_MEDICO')")
    public CitaResponseDTO completarCita(@PathVariable Integer id) {
        return citaService.cambiarEstadoCita(id, "COMPLETADA");
    }

    // --- 6. PUT: REPROGRAMAR ---
    @PutMapping("/{id}/reprogramar")
    @PreAuthorize("hasAnyAuthority('ROL_ADMIN', 'ROL_RECEPCIONISTA')")
    public CitaResponseDTO reprogramarCita(
        @PathVariable Integer id, 
        @RequestParam("nuevaFechaHora") @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) LocalDateTime nuevaFechaHora) 
    {
        return citaService.reprogramarCita(id, nuevaFechaHora);
    }

    // --- 7. DELETE: ELIMINAR CITA ---
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasAuthority('ROL_ADMIN')") 
    public void eliminar(@PathVariable Integer id) {
        citaService.eliminarCita(id);
    }
}