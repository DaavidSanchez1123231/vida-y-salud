package pe.com.VidaySalud.dto;

public class DashboardStatsDTO {

    private long totalPacientes;
    private long totalMedicos;
    private int citasHoy;

    // --- Constructor sin argumentos ---
    public DashboardStatsDTO() {}
    
    // --- Getters y Setters ---
    public long getTotalPacientes() { return totalPacientes; }
    public void setTotalPacientes(long totalPacientes) { this.totalPacientes = totalPacientes; }

    public long getTotalMedicos() { return totalMedicos; }
    public void setTotalMedicos(long totalMedicos) { this.totalMedicos = totalMedicos; }

    public int getCitasHoy() { return citasHoy; }
    public void setCitasHoy(int citasHoy) { this.citasHoy = citasHoy; }
}