package pe.com.VidaySalud.dto;

import java.time.LocalDate;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
public class PacienteRequestDTO {

    
    
    private String dniPaciente;
    private String nomPaciente;
    private String apPaciente;
    private String amPaciente;
    private String emailPaciente;

	public String getDniPaciente() {
		return dniPaciente;
	}
	@DateTimeFormat(iso = DateTimeFormat.ISO.DATE)
    private LocalDate fnPaciente; 

    // ¡CRÍTICO! El tipo debe ser java.lang.String
    private String telfPaciente;
	public void setDniPaciente(String dniPaciente) {
		this.dniPaciente = dniPaciente;
	}
	public String getNomPaciente() {
		return nomPaciente;
	}
	public void setNomPaciente(String nomPaciente) {
		this.nomPaciente = nomPaciente;
	}
	public String getApPaciente() {
		return apPaciente;
	}
	public void setApPaciente(String apPaciente) {
		this.apPaciente = apPaciente;
	}
	public String getAmPaciente() {
		return amPaciente;
	}
	public void setAmPaciente(String amPaciente) {
		this.amPaciente = amPaciente;
	}
	public String getEmailPaciente() {
		return emailPaciente;
	}
	public void setEmailPaciente(String emailPaciente) {
		this.emailPaciente = emailPaciente;
	}
	public LocalDate getFnPaciente() {
		return fnPaciente;
	}
	public void setFnPaciente(LocalDate fnPaciente) {
		this.fnPaciente = fnPaciente;
	}
	public String getTelfPaciente() {
		return telfPaciente;
	}
	public void setTelfPaciente(String telfPaciente) {
		this.telfPaciente = telfPaciente;
	}
}