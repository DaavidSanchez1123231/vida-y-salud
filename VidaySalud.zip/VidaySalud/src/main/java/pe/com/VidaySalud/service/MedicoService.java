package pe.com.VidaySalud.service;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;

import pe.com.VidaySalud.dto.MedicoRequestDTO;
import pe.com.VidaySalud.dto.MedicoResponseDTO;
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Medico;
import pe.com.VidaySalud.model.Usuario;
import pe.com.VidaySalud.model.Rol;
import pe.com.VidaySalud.repository.MedicoRepository;
import pe.com.VidaySalud.repository.UsuarioRepository;
import pe.com.VidaySalud.repository.RolRepository;

@Service
public class MedicoService {

    @Autowired
    private MedicoRepository medicoRepository;
    @Autowired
    private UsuarioRepository usuarioRepository;
    @Autowired
    private RolRepository rolRepository;
    @Autowired
    private PasswordEncoder passwordEncoder;

    public List<MedicoResponseDTO> obtenerTodosLosMedicos() {
        return medicoRepository.findAll()
                .stream()
                .map(this::convertirA_ResponseDTO)
                .collect(Collectors.toList());
    }


    @Transactional
    public MedicoResponseDTO crearMedico(MedicoRequestDTO requestDTO) {
        
        // A. Validar Email
        if (usuarioRepository.findByEmailUsuario(requestDTO.getEmail()).isPresent()) {
            throw new RuntimeException("El email ya está registrado en el sistema");
        }


        Usuario usuario = new Usuario();
        usuario.setEmailUsuario(requestDTO.getEmail());
        usuario.setPasswordUsuario(passwordEncoder.encode(requestDTO.getPassword()));
        
        Rol rolMedico = rolRepository.findByNomRol("ROL_MEDICO")
                .orElseThrow(() -> new ResourceNotFoundException("Error: ROL_MEDICO no configurado en BD"));
        usuario.setRol(rolMedico);
        
        Usuario usuarioGuardado = usuarioRepository.save(usuario);

        Medico medico = new Medico();
        medico.setIdUsuario(usuarioGuardado.getIdUsuario());
        medico.setIdEspecialidad(requestDTO.getIdEspecialidad());
        medico.setCodMedico(requestDTO.getCodMedico());
        medico.setMonMedico(requestDTO.getMonMedico());
        medico.setApMedico(requestDTO.getApMedico());
        medico.setAmMedico(requestDTO.getAmMedico());
        medico.setEstMedico(requestDTO.getEstMedico()); // Ej: "A"
        medico.setUrlFoto(requestDTO.getUrlFoto());

        Medico medicoGuardado = medicoRepository.save(medico);
        return convertirA_ResponseDTO(medicoGuardado);
    }

    public MedicoResponseDTO obtenerMedicoPorId(Integer id) {
        Medico medico = medicoRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + id));
        return convertirA_ResponseDTO(medico);
    }


    public void eliminarMedico(Integer id) {
        if (!medicoRepository.existsById(id)) {
            throw new ResourceNotFoundException("Médico no encontrado con ID: " + id);
        }
        medicoRepository.deleteById(id);
    }


    @Transactional
    public MedicoResponseDTO actualizarMedico(Integer id, MedicoRequestDTO requestDTO) {
        Medico medicoExistente = medicoRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + id));

        medicoExistente.setIdEspecialidad(requestDTO.getIdEspecialidad());
        medicoExistente.setCodMedico(requestDTO.getCodMedico());
        medicoExistente.setMonMedico(requestDTO.getMonMedico());
        medicoExistente.setApMedico(requestDTO.getApMedico());
        medicoExistente.setAmMedico(requestDTO.getAmMedico());
        medicoExistente.setEstMedico(requestDTO.getEstMedico());
        medicoExistente.setUrlFoto(requestDTO.getUrlFoto());
        
        Medico medicoActualizado = medicoRepository.save(medicoExistente);
        return convertirA_ResponseDTO(medicoActualizado);
    }


    public MedicoResponseDTO actualizarMedicoParcial(Integer id, MedicoRequestDTO requestDTO) {
        Medico medicoExistente = medicoRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + id));

        if (requestDTO.getIdEspecialidad() != null) medicoExistente.setIdEspecialidad(requestDTO.getIdEspecialidad());
        if (requestDTO.getCodMedico() != null) medicoExistente.setCodMedico(requestDTO.getCodMedico());
        if (requestDTO.getMonMedico() != null) medicoExistente.setMonMedico(requestDTO.getMonMedico());
        if (requestDTO.getApMedico() != null) medicoExistente.setApMedico(requestDTO.getApMedico());
        if (requestDTO.getAmMedico() != null) medicoExistente.setAmMedico(requestDTO.getAmMedico());
        if (requestDTO.getEstMedico() != null) medicoExistente.setEstMedico(requestDTO.getEstMedico());
        if (requestDTO.getUrlFoto() != null) medicoExistente.setUrlFoto(requestDTO.getUrlFoto());

        Medico medicoActualizado = medicoRepository.save(medicoExistente);
        return convertirA_ResponseDTO(medicoActualizado);
    }


    private MedicoResponseDTO convertirA_ResponseDTO(Medico medico) {
        MedicoResponseDTO dto = new MedicoResponseDTO();
        dto.setIdMedico(medico.getIdMedico());
        dto.setIdEspecialidad(medico.getIdEspecialidad());
        dto.setIdUsuario(medico.getIdUsuario());
        dto.setCodMedico(medico.getCodMedico());
        dto.setMonMedico(medico.getMonMedico());
        dto.setApMedico(medico.getApMedico());
        dto.setAmMedico(medico.getAmMedico());
        dto.setEstMedico(medico.getEstMedico());
        dto.setUrlFoto(medico.getUrlFoto());
        return dto;
    }
}