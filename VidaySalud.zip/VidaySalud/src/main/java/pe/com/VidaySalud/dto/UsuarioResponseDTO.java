package pe.com.VidaySalud.dto;

import lombok.Data;

@Data
public class UsuarioResponseDTO {
    
    private Integer idUsuario;
    private Integer idRol;
    private String emilUsuario;
	public Integer getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	public Integer getIdRol() {
		return idRol;
	}
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}
	public String getEmilUsuario() {
		return emilUsuario;
	}
	public void setEmilUsuario(String emilUsuario) {
		this.emilUsuario = emilUsuario;
	}
    
    
}