package pe.com.VidaySalud.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import pe.com.VidaySalud.dto.UsuarioRequestDTO; // Importar DTO
import pe.com.VidaySalud.dto.UsuarioResponseDTO; // Importar DTO
import pe.com.VidaySalud.service.UsuarioService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

    
    @GetMapping
    public List<UsuarioResponseDTO> obtenerTodos() {
        return usuarioService.obtenerTodosLosUsuarios();
    }

    
    @GetMapping("/{id}")
    public UsuarioResponseDTO obtenerPorId(@PathVariable Integer id) {
        return usuarioService.obtenerUsuarioPorId(id);
    }
    
   
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public UsuarioResponseDTO crear(@RequestBody UsuarioRequestDTO usuarioRequestDTO) {
        return usuarioService.crearUsuario(usuarioRequestDTO);
    }

   
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Integer id) {
        usuarioService.eliminarUsuario(id);
    }
    @PutMapping("/{id}")
    public UsuarioResponseDTO actualizar(@PathVariable Integer id, @RequestBody UsuarioRequestDTO requestDTO) {
        return usuarioService.actualizarUsuario(id, requestDTO);
    }

    @PatchMapping("/{id}")
    public UsuarioResponseDTO actualizarParcial(@PathVariable Integer id, @RequestBody UsuarioRequestDTO requestDTO) {
        return usuarioService.actualizarUsuarioParcial(id, requestDTO);
    }
}