package pe.com.VidaySalud.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import pe.com.VidaySalud.security.JwtAuthenticationFilter;
import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    private final JwtAuthenticationFilter jwtAuthFilter;
    private final AuthenticationProvider authenticationProvider;

    public SecurityConfig(JwtAuthenticationFilter jwtAuthFilter, AuthenticationProvider authenticationProvider) {
        this.jwtAuthFilter = jwtAuthFilter;
        this.authenticationProvider = authenticationProvider;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            // 1. CONFIGURACIÓN CORS
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(csrf -> csrf.disable())
            
            .authorizeHttpRequests(auth -> auth
                
                // 2. PERMISOS PÚBLICOS (CORREGIDO)
                .requestMatchers(HttpMethod.OPTIONS, "/**").permitAll()
                
                // RUTAS DE AUTENTICACIÓN: /auth/login y /auth/registrarPaciente
                .requestMatchers("/auth/**").permitAll() 
                
                // RUTAS DE CONSULTA PÚBLICAS (Para el directorio de staff)
                .requestMatchers(HttpMethod.GET, "/api/medicos").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/especialidades").permitAll()
                
                // 3. Portal del Paciente (Rutas Protegidas)
                .requestMatchers("/api/citas/paciente/**").hasAuthority("PACIENTE")
                .requestMatchers(HttpMethod.POST, "/api/citas").hasAnyAuthority("PACIENTE", "ROL_RECEPCIONISTA")
                
                // Las demás rutas mantienen su protección
                // ... (Omitido por brevedad, el resto de rutas quedan igual) ...

                // 4. Gestión de Pacientes
                .requestMatchers("/api/pacientes/**").hasAuthority("ROL_RECEPCIONISTA")

                // 5. Gestión de Citas
                .requestMatchers(HttpMethod.GET, "/api/citas").hasAuthority("ROL_RECEPCIONISTA")
                .requestMatchers(HttpMethod.GET, "/api/citas/medico/**").hasAnyAuthority("ROL_RECEPCIONISTA", "ROL_MEDICO")
                .requestMatchers(HttpMethod.PUT, "/api/citas/{id}/reprogramar").hasAuthority("ROL_RECEPCIONISTA")
                .requestMatchers(HttpMethod.PUT, "/api/citas/{id}/cancelar").hasAnyAuthority("ROL_RECEPCIONISTA", "PACIENTE")
                .requestMatchers(HttpMethod.PUT, "/api/citas/{id}/completar").hasAuthority("ROL_MEDICO")
                .requestMatchers(HttpMethod.DELETE, "/api/citas/**").hasAuthority("ROL_RECEPCIONISTA")

                // 6. Gestión de Médicos
                .requestMatchers("/api/medicos/**").hasAuthority("ROL_ADMIN") // Permisos CRUD y GET específicos
                
                // 7. Gestión Administrativa
                .requestMatchers("/api/usuarios/**", "/api/roles/**", "/api/especialidades/**").hasAuthority("ROL_ADMIN")
                
                .anyRequest().authenticated()
            )
            
            .sessionManagement(session -> session
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS)
            )
            .authenticationProvider(authenticationProvider)
            .addFilterBefore(jwtAuthFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    // --- DEFINICIÓN DEL BEAN DE CORS ---
    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        configuration.setAllowedOrigins(List.of(
            "http://127.0.0.1:5500",
            "http://localhost:5500",
            "http://localhost:8081" // Por si acaso
        ));
        
        configuration.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS", "PATCH"));
        configuration.setAllowedHeaders(List.of("Authorization", "Content-Type"));
        configuration.setAllowCredentials(true);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}