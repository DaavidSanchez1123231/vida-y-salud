package pe.com.VidaySalud.dto;

import lombok.Data;

@Data
public class AuthLoginRequestDTO {
    
   
    private String emilUsuario; 
    
   
    private String passwordUsuario;


	public String getEmilUsuario() {
		return emilUsuario;
	}


	public void setEmilUsuario(String emilUsuario) {
		this.emilUsuario = emilUsuario;
	}


	public String getPasswordUsuario() {
		return passwordUsuario;
	}


	public void setPasswordUsuario(String passwordUsuario) {
		this.passwordUsuario = passwordUsuario;
	}
    
}