package pe.com.VidaySalud.dto;

import java.time.LocalTime;
import java.time.DayOfWeek;

// Este DTO define la estructura de salida para la tabla de horarios del médico.
public class DisponibilidadResponseDTO {
    
    private Integer idDisponibilidad;
    private DayOfWeek diaSemana; 
    private LocalTime horaInicio; 
    private LocalTime horaFin;
    private String estadoHorario; // Estado: APROBADO o PENDIENTE (usado en el frontend)

    // --- Getters y Setters ---
    
    public Integer getIdDisponibilidad() { return idDisponibilidad; }
    public void setIdDisponibilidad(Integer idDisponibilidad) { this.idDisponibilidad = idDisponibilidad; }

    public DayOfWeek getDiaSemana() { return diaSemana; }
    public void setDiaSemana(DayOfWeek diaSemana) { this.diaSemana = diaSemana; }

    public LocalTime getHoraInicio() { return horaInicio; }
    public void setHoraInicio(LocalTime horaInicio) { this.horaInicio = horaInicio; }

    public LocalTime getHoraFin() { return horaFin; }
    public void setHoraFin(LocalTime horaFin) { this.horaFin = horaFin; }

    public String getEstadoHorario() { return estadoHorario; }
    public void setEstadoHorario(String estadoHorario) { this.estadoHorario = estadoHorario; }
}