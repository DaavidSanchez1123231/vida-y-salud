package pe.com.VidaySalud.dto;

import lombok.Data;

@Data
public class RolDTO {
    
    private Integer idRol; // Se omite al crear, se incluye al responder
    private String nomRol;
	public Integer getIdRol() {
		return idRol;
	}
	public void setIdRol(Integer idRol) {
		this.idRol = idRol;
	}
	public String getNomRol() {
		return nomRol;
	}
	public void setNomRol(String nomRol) {
		this.nomRol = nomRol;
	}
    
}