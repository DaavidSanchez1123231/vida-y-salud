package pe.com.VidaySalud.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import pe.com.VidaySalud.dto.PacienteRequestDTO;
import pe.com.VidaySalud.dto.PacienteResponseDTO;
import pe.com.VidaySalud.service.PacienteService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/pacientes")
public class PacienteController {

    @Autowired
    private PacienteService pacienteService;

    @GetMapping
    public List<PacienteResponseDTO> obtenerTodos() {
        return pacienteService.obtenerTodosLosPacientes();
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public PacienteResponseDTO crear(@RequestBody PacienteRequestDTO requestDTO) {
        return pacienteService.crearPaciente(requestDTO);
    }

    @GetMapping("/{id}")
    public PacienteResponseDTO obtenerPorId(@PathVariable Integer id) {
        return pacienteService.obtenerPacientePorId(id);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void eliminar(@PathVariable Integer id) {
        pacienteService.eliminarPaciente(id);
    }

    @PutMapping("/{id}")
    public PacienteResponseDTO actualizar(
        @PathVariable Integer id, 
        @RequestBody PacienteRequestDTO requestDTO) 
    {
        return pacienteService.actualizarPaciente(id, requestDTO);
    }

   
    @PatchMapping("/{id}")
    public PacienteResponseDTO actualizarParcial(
        @PathVariable Integer id, 
        @RequestBody PacienteRequestDTO requestDTO) 
    {
        return pacienteService.actualizarPacienteParcial(id, requestDTO);
    }
}