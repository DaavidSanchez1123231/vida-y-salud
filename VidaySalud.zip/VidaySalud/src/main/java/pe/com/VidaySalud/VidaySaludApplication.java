package pe.com.VidaySalud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling; // <-- 1. IMPORTA ESTO

@SpringBootApplication
@EnableScheduling 
public class VidaySaludApplication {

	public static void main(String[] args) {
		SpringApplication.run(VidaySaludApplication.class, args);
	}

}