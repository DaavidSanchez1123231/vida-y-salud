package pe.com.VidaySalud.rest;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
// --- IMPORTANTE: Estas 3 líneas suelen faltar y causan error en @PreAuthorize ---
import org.springframework.security.access.prepost.PreAuthorize; 
import org.springframework.web.bind.annotation.*;
// -----------------------------------------------------------------------------

import pe.com.VidaySalud.dto.MedicoRequestDTO;
import pe.com.VidaySalud.dto.MedicoResponseDTO;
import pe.com.VidaySalud.service.MedicoService;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/medicos")
public class MedicoController {

    @Autowired
    private MedicoService medicoService;

    // 1. OBTENER TODOS
    @GetMapping
    public List<MedicoResponseDTO> obtenerTodos() {
        return medicoService.obtenerTodosLosMedicos();
    }

    // 2. CREAR (Solo Admin)
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @PreAuthorize("hasAuthority('ROL_ADMIN')") 
    public MedicoResponseDTO crear(@RequestBody MedicoRequestDTO requestDTO) {
        return medicoService.crearMedico(requestDTO);
    }

    // 3. OBTENER POR ID
    @GetMapping("/{id}")
    public MedicoResponseDTO obtenerPorId(@PathVariable Integer id) {
        // Si esta línea marca error rojo, es porque MedicoService NO tiene el método obtenerMedicoPorId
        return medicoService.obtenerMedicoPorId(id);
    }

    // 4. ELIMINAR (Solo Admin)
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasAuthority('ROL_ADMIN')")
    public void eliminar(@PathVariable Integer id) {
        // Si esta línea marca error rojo, es porque MedicoService NO tiene el método eliminarMedico
        medicoService.eliminarMedico(id);
    }

    // 5. ACTUALIZAR (Solo Admin)
    @PutMapping("/{id}")
    @PreAuthorize("hasAuthority('ROL_ADMIN')")
    public MedicoResponseDTO actualizar(@PathVariable Integer id, @RequestBody MedicoRequestDTO requestDTO) {
        return medicoService.actualizarMedico(id, requestDTO);
    }

    // 6. ACTUALIZAR PARCIAL (Solo Admin)
    @PatchMapping("/{id}")
    @PreAuthorize("hasAuthority('ROL_ADMIN')")
    public MedicoResponseDTO actualizarParcial(@PathVariable Integer id, @RequestBody MedicoRequestDTO requestDTO) {
        return medicoService.actualizarMedicoParcial(id, requestDTO);
    }
}