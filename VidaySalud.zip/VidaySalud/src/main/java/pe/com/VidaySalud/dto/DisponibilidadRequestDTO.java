package pe.com.VidaySalud.dto;

import java.time.DayOfWeek;
// Usamos el API de tiempo de Java para fechas y horas
import java.time.LocalTime;

public class DisponibilidadRequestDTO {
    
	private Integer idDisponibilidad;
    private String diaSemana; // <-- ahora sí
    private LocalTime horaInicio;
    private Integer idMedico;
    private LocalTime horaFin;
    private String estadoHorario;
    
	public Integer getIdMedico() {
		return idMedico;
	}
	public void setIdMedico(Integer idMedico) {
		this.idMedico = idMedico;
	}
	public Integer getIdDisponibilidad() {
		return idDisponibilidad;
	}
	public void setIdDisponibilidad(Integer idDisponibilidad) {
		this.idDisponibilidad = idDisponibilidad;
	}
	public String getDiaSemana() {
		return diaSemana;
	}
	public void setDiaSemana(String diaSemana) {
		this.diaSemana = diaSemana;
	}
	public LocalTime getHoraInicio() {
		return horaInicio;
	}
	public void setHoraInicio(LocalTime horaInicio) {
		this.horaInicio = horaInicio;
	}
	public LocalTime getHoraFin() {
		return horaFin;
	}
	public void setHoraFin(LocalTime horaFin) {
		this.horaFin = horaFin;
	}
	public String getEstadoHorario() {
		return estadoHorario;
	}
	public void setEstadoHorario(String estadoHorario) {
		this.estadoHorario = estadoHorario;
	}
    
}