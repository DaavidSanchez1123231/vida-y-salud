package pe.com.VidaySalud.dto;

import lombok.Data;

@Data
public class EspecialidadDTO {

    private Integer idEspecialidad; // Se omite al crear, se incluye al responder
    private String nomEspecialidad;
    private String estEspecialidad; // Mapeado como String (es nvarchar)
	public Integer getIdEspecialidad() {
		return idEspecialidad;
	}
	public void setIdEspecialidad(Integer idEspecialidad) {
		this.idEspecialidad = idEspecialidad;
	}
	public String getNomEspecialidad() {
		return nomEspecialidad;
	}
	public void setNomEspecialidad(String nomEspecialidad) {
		this.nomEspecialidad = nomEspecialidad;
	}
	public String getEstEspecialidad() {
		return estEspecialidad;
	}
	public void setEstEspecialidad(String estEspecialidad) {
		this.estEspecialidad = estEspecialidad;
	}
    
}