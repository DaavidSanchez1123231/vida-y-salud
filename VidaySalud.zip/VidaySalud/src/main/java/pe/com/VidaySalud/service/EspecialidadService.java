package pe.com.VidaySalud.service;

import java.util.List;
import java.util.stream.Collectors; // Import para mapear listas
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.VidaySalud.dto.EspecialidadDTO; // Importar DTO
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Especialidad;
import pe.com.VidaySalud.repository.EspecialidadRepository;

@Service
public class EspecialidadService {

    @Autowired
    private EspecialidadRepository especialidadRepository;

    public List<EspecialidadDTO> obtenerTodasLasEspecialidades() {
        return especialidadRepository.findAll()
                .stream()
                .map(this::convertirA_DTO) // Mapear
                .collect(Collectors.toList());
    }

    public EspecialidadDTO crearEspecialidad(EspecialidadDTO dto) {
        Especialidad especialidad = convertirA_Entidad(dto);
        Especialidad especialidadGuardada = especialidadRepository.save(especialidad);
        return convertirA_DTO(especialidadGuardada);
    }
    
    public EspecialidadDTO obtenerEspecialidadPorId(Integer id) {
        Especialidad especialidad = especialidadRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Especialidad no encontrada con ID: " + id));
        return convertirA_DTO(especialidad);
    }

    public void eliminarEspecialidad(Integer id) {
        if (!especialidadRepository.existsById(id)) {
            throw new ResourceNotFoundException("Especialidad no encontrada con ID: " + id);
        }
        especialidadRepository.deleteById(id);
    }

 
    private EspecialidadDTO convertirA_DTO(Especialidad especialidad) {
        EspecialidadDTO dto = new EspecialidadDTO();
        dto.setIdEspecialidad(especialidad.getIdEspecialidad());
        dto.setNomEspecialidad(especialidad.getNomEspecialidad());
        dto.setEstEspecialidad(especialidad.getEstEspecialidad());
        return dto;
    }

    private Especialidad convertirA_Entidad(EspecialidadDTO dto) {
        Especialidad especialidad = new Especialidad();

        especialidad.setNomEspecialidad(dto.getNomEspecialidad());
        especialidad.setEstEspecialidad(dto.getEstEspecialidad());
        return especialidad;
    }
    public EspecialidadDTO actualizarEspecialidad(Integer id, EspecialidadDTO dto) {
        
        Especialidad especialidad = especialidadRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Especialidad no encontrada con ID: " + id));


        especialidad.setNomEspecialidad(dto.getNomEspecialidad());
        especialidad.setEstEspecialidad(dto.getEstEspecialidad());
        

        Especialidad actualizada = especialidadRepository.save(especialidad);
        return convertirA_DTO(actualizada);
    }

    public EspecialidadDTO actualizarEspecialidadParcial(Integer id, EspecialidadDTO dto) {

        Especialidad especialidad = especialidadRepository.findById(id)
            .orElseThrow(() -> new ResourceNotFoundException("Especialidad no encontrada con ID: " + id));


        if (dto.getNomEspecialidad() != null) {
            especialidad.setNomEspecialidad(dto.getNomEspecialidad());
        }
        if (dto.getEstEspecialidad() != null) {
            especialidad.setEstEspecialidad(dto.getEstEspecialidad());
        }
        

        Especialidad actualizada = especialidadRepository.save(especialidad);
        return convertirA_DTO(actualizada);
    }
}