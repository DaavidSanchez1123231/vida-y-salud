package pe.com.VidaySalud.model;

import jakarta.persistence.*;
import java.time.DayOfWeek;
import java.time.LocalTime;

@Entity
@Table(name = "disponibilidad")
public class Disponibilidad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer idDisponibilidad;

    // Relación con el Médico que establece el horario
    @ManyToOne
    @JoinColumn(name = "id_medico", nullable = false)
    private Medico medico;

    // Día de la semana (LUNES, MARTES, etc.)
    @Enumerated(EnumType.STRING)
    @Column(name = "dia_semana", nullable = false, length = 10)
    private DayOfWeek diaSemana;

    // Hora de inicio del turno
    @Column(name = "hora_inicio", nullable = false)
    private LocalTime horaInicio;

    // Hora de fin del turno
    @Column(name = "hora_fin", nullable = false)
    private LocalTime horaFin;
    
 // En pe.com.VidaySalud.model.Disponibilidad.java

 // Añadir esto a las columnas de la entidad:
 @Column(name = "estado_horario", nullable = false) // Asumimos NOT NULL para controlar el flujo
 private String estadoHorario = "PENDIENTE"; // Valor por defecto

    // --- Constructor sin argumentos (Necesario por JPA) ---
    public Disponibilidad() {
    }

    public String getEstadoHorario() {
		return estadoHorario;
	}

	public void setEstadoHorario(String estadoHorario) {
		this.estadoHorario = estadoHorario;
	}

	// --- Getters y Setters ---
    public Integer getIdDisponibilidad() {
        return idDisponibilidad;
    }

    public void setIdDisponibilidad(Integer idDisponibilidad) {
        this.idDisponibilidad = idDisponibilidad;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public DayOfWeek getDiaSemana() {
        return diaSemana;
    }

    public void setDiaSemana(DayOfWeek diaSemana) {
        this.diaSemana = diaSemana;
    }

    public LocalTime getHoraInicio() {
        return horaInicio;
    }

    public void setHoraInicio(LocalTime horaInicio) {
        this.horaInicio = horaInicio;
    }

    public LocalTime getHoraFin() {
        return horaFin;
    }

    public void setHoraFin(LocalTime horaFin) {
        this.horaFin = horaFin;
    }
}