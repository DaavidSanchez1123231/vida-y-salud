package pe.com.VidaySalud.dto;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit; // Necesario para la validación
import com.fasterxml.jackson.annotation.JsonFormat;

public class CitaRequestDTO {

    private Integer idPaciente;
    private Integer idMedico;
    
    // El formato ISO es esencial para que Spring lo parsee
    @JsonFormat(pattern = "yyyy-MM-dd'T'HH:mm:ss") 
    private LocalDateTime fechaHora;
    
    // Campos de negocio
    private String motivoConsulta; 
    private String estado; 

    // --- Getters y Setters (Completos) ---
    public Integer getIdPaciente() {
        return idPaciente;
    }
    public void setIdPaciente(Integer idPaciente) {
        this.idPaciente = idPaciente;
    }
    public Integer getIdMedico() {
        return idMedico;
    }
    public void setIdMedico(Integer idMedico) {
        this.idMedico = idMedico;
    }
    public LocalDateTime getFechaHora() {
        return fechaHora;
    }
    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }
    public String getMotivoConsulta() {
        return motivoConsulta;
    }
    public void setMotivoConsulta(String motivoConsulta) {
        this.motivoConsulta = motivoConsulta;
    }
    public String getEstado() {
        return estado;
    }
    public void setEstado(String estado) {
        this.estado = estado;
    }
}