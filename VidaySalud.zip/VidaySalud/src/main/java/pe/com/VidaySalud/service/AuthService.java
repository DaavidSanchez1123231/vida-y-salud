package pe.com.VidaySalud.service;

import java.util.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.com.VidaySalud.dto.AuthLoginRequestDTO;
import pe.com.VidaySalud.dto.AuthLoginResponseDTO;
import pe.com.VidaySalud.dto.RegisterRequestDTO;
import pe.com.VidaySalud.exception.BusinessConflictException;
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Paciente;
import pe.com.VidaySalud.model.Rol;
import pe.com.VidaySalud.model.Usuario;
import pe.com.VidaySalud.repository.PacienteRepository;
import pe.com.VidaySalud.repository.RolRepository;
import pe.com.VidaySalud.repository.UsuarioRepository;
import pe.com.VidaySalud.security.JwtService;

@Service
public class AuthService {

    @Autowired private UsuarioRepository usuarioRepository;
    @Autowired private PacienteRepository pacienteRepository;
    @Autowired private RolRepository rolRepository;
    @Autowired private JwtService jwtService;
    @Autowired private PasswordEncoder passwordEncoder;
    @Autowired private AuthenticationManager authenticationManager;

    // --- LÓGICA DE LOGIN (Punto de Entrada Único) ---
    public AuthLoginResponseDTO login(AuthLoginRequestDTO request) {
        
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(request.getEmilUsuario(), request.getPasswordUsuario())
        );

        Usuario usuario = usuarioRepository.findByEmailUsuario(request.getEmilUsuario())
            .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));

        String token = jwtService.generateToken(usuario);
        String nombreRol = usuario.getRol().getNomRol();

        // 5. RETORNAR EL PAYLOAD COMPLETO
        return new AuthLoginResponseDTO(
            token, 
            usuario.getEmailUsuario(), 
            nombreRol, 
            usuario.getIdUsuario()
        );
    }
    
    // --- LÓGICA DE REGISTRO PÚBLICO (Crea PACIENTE) ---
    @Transactional
    public AuthLoginResponseDTO registrarPaciente(RegisterRequestDTO request) {
        
        // 1. VALIDACIÓN ESTRICTA DE FORMATO (DNI y Teléfono)
        if (request.getDniPaciente() == null || !request.getDniPaciente().matches("\\d{8}")) {
            throw new IllegalArgumentException("El DNI debe contener exactamente 8 dígitos numéricos.");
        }
        if (request.getTelefono() == null || !request.getTelefono().matches("\\d{9}")) {
            throw new IllegalArgumentException("El Teléfono debe contener exactamente 9 dígitos numéricos.");
        }

        // 2. VALIDACIÓN DE DUPLICADOS
        if (usuarioRepository.findByEmailUsuario(request.getEmilUsuario()).isPresent()) {
            throw new BusinessConflictException("El email ya está registrado.");
        }
        if (pacienteRepository.existsByDniPaciente(request.getDniPaciente())) {
            throw new BusinessConflictException("El DNI ya está registrado.");
        }

        // 3. Obtener Rol PACIENTE y Crear Usuario
        Rol rolPaciente = rolRepository.findByNomRol("PACIENTE")
                .orElseThrow(() -> new ResourceNotFoundException("Error: Rol PACIENTE no existe en la BD."));

        Usuario usuario = new Usuario();
        usuario.setEmailUsuario(request.getEmilUsuario());
        usuario.setRol(rolPaciente); // Asignación de rol forzada
        usuario.setPasswordUsuario(passwordEncoder.encode(request.getPasswordUsuario()));
        
        Usuario usuarioGuardado = usuarioRepository.save(usuario); 

        // 4. Crear Datos Paciente (Perfil)
        Paciente paciente = new Paciente();
        paciente.setDniPaciente(request.getDniPaciente());
        paciente.setNomPaciente(request.getNomPaciente());
        paciente.setApPaciente(request.getApPaciente());
        paciente.setAmPaciente(request.getAmPaciente());
        paciente.setEmailPaciente(request.getEmilUsuario());
        
        // Campos corregidos y agregados
        paciente.setFnPaciente(request.getFnPaciente()); // LocalDate
        paciente.setTelfPaciente(request.getTelefono()); // String (9 dígitos)

        // Vinculación (Shadow ID)
        paciente.setIdUsuario(usuarioGuardado.getIdUsuario()); 

        pacienteRepository.save(paciente); // Guardar perfil de paciente

        // 5. Generar Token y Respuesta
        String token = jwtService.generateToken(usuarioGuardado);
        
        return new AuthLoginResponseDTO(
            token,
            usuarioGuardado.getEmailUsuario(),
            "PACIENTE",
            usuarioGuardado.getIdUsuario()
        );
    }
}