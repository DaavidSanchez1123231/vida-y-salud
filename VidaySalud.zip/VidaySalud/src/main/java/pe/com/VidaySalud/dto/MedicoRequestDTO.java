package pe.com.VidaySalud.dto;

import lombok.Data;

@Data
public class MedicoRequestDTO {

    // --- Nuevos campos para crear el Login ---
    private String email;
    private String password; 
    
    // --- Campos del Médico ---
    private Integer idEspecialidad;
    private Integer idUsuario; // (Opcional, se genera automático al crear)
    private String codMedico;
    private String monMedico;  // Nombre
    private String apMedico;   // Apellido Paterno
    private String amMedico;   // Apellido Materno
    private String estMedico;  // Estado (Activo/Inactivo)
    private String urlFoto;    // URL de la imagen
    
    // Getters y Setters (Lombok @Data ya los hace, pero si no usas Lombok, mantenlos)
    // ... tus getters y setters existentes ...
    
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
	public Integer getIdEspecialidad() {
		return idEspecialidad;
	}
	public void setIdEspecialidad(Integer idEspecialidad) {
		this.idEspecialidad = idEspecialidad;
	}
	public Integer getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(Integer idUsuario) {
		this.idUsuario = idUsuario;
	}
	public String getCodMedico() {
		return codMedico;
	}
	public void setCodMedico(String codMedico) {
		this.codMedico = codMedico;
	}
	public String getMonMedico() {
		return monMedico;
	}
	public void setMonMedico(String monMedico) {
		this.monMedico = monMedico;
	}
	public String getApMedico() {
		return apMedico;
	}
	public void setApMedico(String apMedico) {
		this.apMedico = apMedico;
	}
	public String getAmMedico() {
		return amMedico;
	}
	public void setAmMedico(String amMedico) {
		this.amMedico = amMedico;
	}
	public String getEstMedico() {
		return estMedico;
	}
	public void setEstMedico(String estMedico) {
		this.estMedico = estMedico;
	}
	public String getUrlFoto() {
		return urlFoto;
	}
	public void setUrlFoto(String urlFoto) {
		this.urlFoto = urlFoto;
	}
    
}