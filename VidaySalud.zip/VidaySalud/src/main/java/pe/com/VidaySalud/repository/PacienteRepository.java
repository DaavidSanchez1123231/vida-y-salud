package pe.com.VidaySalud.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import pe.com.VidaySalud.model.Paciente;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Integer> {

    // ESTO ELIMINA EL ERROR ROJO DE "existsByDniPaciente"
    boolean existsByDniPaciente(String dniPaciente);

}