package pe.com.VidaySalud.service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.com.VidaySalud.dto.DisponibilidadRequestDTO;
import pe.com.VidaySalud.dto.DisponibilidadResponseDTO; // Asegúrate de tener este DTO creado
import pe.com.VidaySalud.exception.ResourceNotFoundException;
import pe.com.VidaySalud.model.Cita;
import pe.com.VidaySalud.model.Disponibilidad;
import pe.com.VidaySalud.model.Medico;
import pe.com.VidaySalud.repository.CitaRepository;
import pe.com.VidaySalud.repository.DisponibilidadRepository;
import pe.com.VidaySalud.repository.MedicoRepository;

@Service
public class HorarioService {

    @Autowired private CitaRepository citaRepository;
    @Autowired private DisponibilidadRepository disponibilidadRepository; 
    @Autowired private MedicoRepository medicoRepository; 
    
    private static final int DURACION_CITA_MINUTOS = 30;

    // -----------------------------------------------------------------------
    // MÉTODOS PÚBLICOS
    // -----------------------------------------------------------------------

    /**
     * 1. GET /api/horarios/disponible: Calcula los slots libres para una fecha y médico.
     */
    public List<String> obtenerHorariosDisponibles(Integer idMedico, LocalDate fecha) {
        
        DayOfWeek diaSemana = fecha.getDayOfWeek(); 
        
        // 1. OBTENER HORAS TEÓRICAS DE TRABAJO
        List<Disponibilidad> horariosDisp = disponibilidadRepository.findByMedicoIdMedicoAndDiaSemana(idMedico, diaSemana);
        
        if (horariosDisp.isEmpty()) {
            return new ArrayList<>(); 
        }

        // 2. GENERAR SLOTS TEÓRICOS
        List<LocalTime> slotsTeoricos = horariosDisp.stream()
            .flatMap(disp -> generarSlots(disp.getHoraInicio(), disp.getHoraFin(), DURACION_CITA_MINUTOS).stream())
            .collect(Collectors.toList());

        // 3. OBTENER HORARIOS OCUPADOS (Usando el @Query corregido de CitaRepository)
        LocalDateTime startOfDay = fecha.atStartOfDay();
        LocalDateTime endOfDay = fecha.atTime(LocalTime.MAX);
        
        List<Cita> citasOcupadas = citaRepository.findByMedicoIdAndFecha(
            idMedico, 
            startOfDay, 
            endOfDay 
        ); 
        
        List<LocalTime> horasOcupadas = citasOcupadas.stream()
            .map(cita -> cita.getFechaHora().toLocalTime())
            .collect(Collectors.toList());
        
        // 4. RESTAR Y FILTRAR
        List<LocalTime> slotsDisponibles = slotsTeoricos.stream()
            .filter(slot -> !horasOcupadas.contains(slot))
            .collect(Collectors.toList());

        return slotsDisponibles.stream()
            .map(LocalTime::toString)
            .collect(Collectors.toList());
    }

    /**
     * 2. POST /api/horarios/medico: Registra un nuevo turno de disponibilidad.
     */
    @Transactional
    public void registrarDisponibilidad(DisponibilidadRequestDTO request) {
        
        if (request.getHoraFin().isBefore(request.getHoraInicio()) || request.getHoraFin().equals(request.getHoraInicio())) {
            throw new IllegalArgumentException("La hora de fin debe ser posterior a la hora de inicio.");
        }
        
        Medico medico = medicoRepository.findById(request.getIdMedico())
            .orElseThrow(() -> new ResourceNotFoundException("Médico no encontrado con ID: " + request.getIdMedico()));
        
        // CRÍTICO: Conversión segura del String de español a DayOfWeek de Java
        DayOfWeek dia = mapDiaSemana(request.getDiaSemana());
        
        Disponibilidad nuevaDisp = new Disponibilidad();
        nuevaDisp.setMedico(medico);
        nuevaDisp.setDiaSemana(dia);
        nuevaDisp.setHoraInicio(request.getHoraInicio());
        nuevaDisp.setHoraFin(request.getHoraFin());
        nuevaDisp.setEstadoHorario("PENDIENTE"); // Asignar estado inicial
        
        disponibilidadRepository.save(nuevaDisp);
    }

    /**
     * 3. GET /api/horarios/medico: Obtiene la lista completa de horarios registrados (para la tabla).
     */
    public List<DisponibilidadResponseDTO> obtenerHorariosRegistradosPorMedico(Integer idMedico) {
        
        List<Disponibilidad> horarios = disponibilidadRepository.findByMedicoIdMedico(idMedico); 
        
        return horarios.stream()
                .map(this::convertirADisponibilidadDTO)
                .collect(Collectors.toList());
    }
    
    // -----------------------------------------------------------------------
    // MAPPERS Y HELPERS
    // -----------------------------------------------------------------------

    /**
     * MÉTODO DE CORRECCIÓN: Convierte el nombre del día de español a DayOfWeek.
     */
    private DayOfWeek mapDiaSemana(String dia) {
        return switch (dia.toUpperCase()) {
            case "LUNES" -> DayOfWeek.MONDAY;
            case "MARTES" -> DayOfWeek.TUESDAY;
            case "MIÉRCOLES", "MIERCOLES" -> DayOfWeek.WEDNESDAY;
            case "JUEVES" -> DayOfWeek.THURSDAY;
            case "VIERNES" -> DayOfWeek.FRIDAY;
            case "SÁBADO", "SABADO" -> DayOfWeek.SATURDAY;
            case "DOMINGO" -> DayOfWeek.SUNDAY;
            default -> throw new IllegalArgumentException("Día de la semana inválido: " + dia);
        };
    }
    
    /**
     * Genera slots de tiempo para el cálculo de disponibilidad.
     */
    private List<LocalTime> generarSlots(LocalTime inicio, LocalTime fin, int intervaloMinutos) {
        List<LocalTime> slots = new ArrayList<>();
        LocalTime actual = inicio;
        
        while (actual.plusMinutes(intervaloMinutos).isBefore(fin) || actual.plusMinutes(intervaloMinutos).equals(fin)) {
            slots.add(actual);
            actual = actual.plusMinutes(intervaloMinutos);
        }
        return slots;
    }

    /**
     * Convierte la Entidad Disponibilidad al DTO de Respuesta.
     */
    private DisponibilidadResponseDTO convertirADisponibilidadDTO(Disponibilidad disp) {
        DisponibilidadResponseDTO dto = new DisponibilidadResponseDTO();
        dto.setIdDisponibilidad(disp.getIdDisponibilidad());
        dto.setDiaSemana(disp.getDiaSemana());
        dto.setHoraInicio(disp.getHoraInicio());
        dto.setHoraFin(disp.getHoraFin());
        
        // Este campo debe existir en la entidad después de la corrección
        dto.setEstadoHorario(disp.getEstadoHorario()); 
        
        return dto;
    }
}