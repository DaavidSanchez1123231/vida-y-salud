package pe.com.VidaySalud.repository;

import pe.com.VidaySalud.model.Cita;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param; // <-- IMPORTANTE
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CitaRepository extends JpaRepository<Cita, Integer> {

    // 1. EXISTENCIA / PREVENCIÓN DE DUPLICADOS
    boolean existsByIdMedicoAndFechaHora(Integer idMedico, LocalDateTime fechaHora);

    // 2. CONSULTA BÁSICA POR ID
    List<Cita> findByIdMedico(Integer idMedico);
    List<Cita> findByIdPaciente(Integer idPaciente);

    // 3. CONSULTA POR RANGO DE FECHA (Para estadísticas. Línea 13 corregida.)
    // La firma original fue corregida para eliminar el 'idPaciente' extra.
    List<Cita> findByFechaHoraBetween(LocalDateTime start, LocalDateTime end); 

    // 4. CONSULTA RANGO MÉDICO (Usada en HorarioService para chequeo de ocupación)
    // Se agregan las anotaciones @Param para evitar errores de ejecución.
    @Query("SELECT c FROM Cita c WHERE c.idMedico = :idMedico " + 
           "AND c.fechaHora BETWEEN :startOfDay AND :endOfDay")
    List<Cita> findByMedicoIdAndFecha(
        @Param("idMedico") Integer idMedico, 
        @Param("startOfDay") LocalDateTime startOfDay, 
        @Param("endOfDay") LocalDateTime endOfDay
    );

    // 5. CONSULTA RANGO PACIENTE (Usada en el Dashboard de Pacientes para historial)
    // Usa los nombres de campo exactos de tu entidad.
    @Query("SELECT c FROM Cita c WHERE c.idPaciente = :idPaciente AND c.fechaHora BETWEEN :inicio AND :fin")
    List<Cita> findByPacienteAndDateRange(
        @Param("idPaciente") Integer idPaciente, 
        @Param("inicio") LocalDateTime inicio, 
        @Param("fin") LocalDateTime fin
    );
}