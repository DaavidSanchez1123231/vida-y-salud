package pe.com.VidaySalud.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pe.com.VidaySalud.dto.DashboardStatsDTO;
import pe.com.VidaySalud.repository.CitaRepository;
import pe.com.VidaySalud.repository.MedicoRepository;
import pe.com.VidaySalud.repository.PacienteRepository;

@Service
public class StatsService {

    @Autowired private MedicoRepository medicoRepository;
    @Autowired private PacienteRepository pacienteRepository;
    @Autowired private CitaRepository citaRepository;

    /**
     * Reúne todas las estadísticas clave para el Dashboard.
     */
    public DashboardStatsDTO getDashboardStats() {
        LocalDateTime startOfDay = LocalDate.now().atStartOfDay();
        LocalDateTime endOfDay = LocalDate.now().atTime(23, 59, 59);

        DashboardStatsDTO stats = new DashboardStatsDTO();
        
        // 1. Conteo simple de entidades (asumiendo que los repositorios extienden JpaRepository)
        stats.setTotalMedicos(medicoRepository.count());
        stats.setTotalPacientes(pacienteRepository.count());
        
        // 2. Conteo de citas del día (usando el método del CitaRepository que ya tienes)
        // Usamos .size() porque el método devuelve una lista
        stats.setCitasHoy(citaRepository.findByFechaHoraBetween(startOfDay, endOfDay).size());
        
        return stats;
    }
}