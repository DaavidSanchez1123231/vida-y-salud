package pe.com.VidaySalud.service;

import jakarta.mail.MessagingException;
import jakarta.mail.internet.MimeMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender; 

    @Value("${spring.mail.username}")
    private String fromEmail;

    /**
     * MÉTODO 1: TEXTO PLANO (El que ya tenías)
     * Útil para notificaciones rápidas o logs.
     */
    public void sendSimpleMessage(String to, String subject, String body) {
        try {
            SimpleMailMessage message = new SimpleMailMessage();
            
            message.setFrom(fromEmail);
            message.setTo(to);
            message.setSubject(subject);
            message.setText(body);
            
            mailSender.send(message);
            System.out.println("Correo de texto simple enviado a: " + to);
            
        } catch (Exception e) {
            System.err.println("Error al enviar correo simple: " + e.getMessage());
        }
    }

    /**
     * MÉTODO 2: HTML (NUEVO)
     * Envía un correo con diseño bonito para la bienvenida.
     */
    public void enviarCorreoBienvenida(String destinatario, String nombrePaciente) {
        try {
            // Usamos MimeMessage en lugar de SimpleMailMessage para soportar HTML
            MimeMessage message = mailSender.createMimeMessage();
            MimeMessageHelper helper = new MimeMessageHelper(message, true, "UTF-8");

            helper.setFrom(fromEmail);
            helper.setTo(destinatario);
            helper.setSubject("¡Bienvenido a Clínica Salud y Vida!");

            // Construimos el HTML usando "Text Blocks" (Java 15+)
            String htmlContent = """
                <div style='font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #ddd; border-radius: 10px; overflow: hidden;'>
                    <div style='background-color: #0d6efd; padding: 20px; text-align: center; color: white;'>
                        <h1>¡Bienvenido/a, %s!</h1>
                    </div>
                    <div style='padding: 20px; background-color: #ffffff;'>
                        <p>Hola <strong>%s</strong>,</p>
                        <p>Tu cuenta en <strong>Clínica Salud y Vida</strong> ha sido creada exitosamente.</p>
                        <hr>
                        <p>Ahora puedes ingresar a nuestro portal para:</p>
                        <ul>
                            <li>Reservar tus citas médicas en línea.</li>
                            <li>Ver tu historial de atenciones.</li>
                            <li>Gestionar tu perfil.</li>
                        </ul>
                        <div style='text-align: center; margin: 30px 0;'>
                            <a href='http://localhost:5500/login.html' style='background-color: #198754; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;'>Ir al Portal</a>
                        </div>
                        <p style='font-size: 12px; color: #777;'>Si no reconoces este registro, por favor contacta con soporte.</p>
                    </div>
                    <div style='background-color: #f8f9fa; padding: 10px; text-align: center; font-size: 12px; color: #555;'>
                        &copy; 2025 Clínica Salud y Vida
                    </div>
                </div>
            """.formatted(nombrePaciente, nombrePaciente);

            // El 'true' indica que el contenido es HTML
            helper.setText(htmlContent, true);

            mailSender.send(message);
            System.out.println("Correo HTML de bienvenida enviado a: " + destinatario);

        } catch (MessagingException e) {
            System.err.println("Error al enviar correo HTML: " + e.getMessage());
            // No lanzamos la excepción para no romper el flujo de registro si el correo falla
        }
    }
}